# LedgerBook cPanel Deployment

This package contains all files needed to deploy LedgerBook to cPanel.

## Quick Start

1. Upload all files to your chosen directory on your cPanel account
2. Run setup_cpanel.sh to set up the environment
3. Update the .htaccess file with your actual path
4. Configure the Python application in cPanel
5. Visit your site to start using LedgerBook

For detailed instructions, see DEPLOY_TO_CPANEL.md

## Testing

Run `python check_app.py` to verify the setup is working correctly.
